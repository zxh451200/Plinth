# Plinth Complete Web Assets — Batch Fixed

This release batch-replaces the previous Plinth logo/icon derivatives. It is intended for the Plinth website and its related developer-facing pages.

## Batch repair
- All logo symbol PNGs, horizontal/stacked lockups, application icons, favicon, PWA, Apple touch icon, OG/X/GitHub lockups and hero artwork are now derived from one cleaned P master.
- Removed the former dark navy matte and detached low-intensity halo pixels from the approved P artwork.
- Smoothed the outer silhouette, removed small irregular contour pixels, and decontaminated antialiased edge RGB against the original navy matte.
- Kept the designed cyan/white and purple rim highlights that belong to the 3D surface. No separate drop shadow or outer glow is added by the export pipeline.
- Dark/light logo and app-icon backgrounds are generated consistently from the same mark.
- Product and feature illustrations that do not contain a logo are retained as independent website images.

## Main folders
- `logo/master/`: shared transparent P master.
- `logo/png/`: symbol and lockup PNG exports.
- `logo/svg/`: self-contained SVG wrappers.
- `icons/`: app icons, Favicon, ICO, PWA and Apple touch assets.
- `web-images/`: separate product, feature, hero background and documentation images.
- `backgrounds/`: non-branded background artwork and brand pattern, plus branded hero lockup variants.
- `social/`: OG, X and GitHub assets.
- `marketing/`: branded hero artwork.
- `preview/` and `previews/`: brand/edge QA previews and a web-image contact sheet.

## Format caveat
The approved Plinth P is a 3D raster master. SVG files are self-contained wrappers with embedded PNG artwork for visual fidelity; they are not fully editable Bézier-vector paths. The legacy `symbol-vector-*.png` names are retained for backwards compatibility, but those files are PNG exports, not vector paths.

`reference/approved-plinth-hero-reference.png` is retained only as a historical concept reference. Use the new files under `logo/`, `marketing/`, `social/` and `web-images/` for the live website.

## Usage
Place the package under a static public asset path, for example `public/assets/brand/plinth/`. Use the dark/light lockups appropriate to the background; use app icon and favicon variants for application/browser surfaces.
