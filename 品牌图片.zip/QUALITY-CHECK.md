# Plinth Batch Fix — Quality Check

## Batch scope
The original Plinth web-asset package was audited. The common P mark used by symbol PNGs, horizontal/stacked lockups, application icons, favicon, PWA, OG, X and GitHub artwork has been replaced with a single cleaned export master.

## Edge treatment
- Removed the former dark navy background matte from the approved P source.
- Suppressed detached low-intensity halo/background pixels.
- Smoothed the silhouette mask and removed small irregular contour pixels.
- Decontaminated antialiased edge RGB against the original navy matte.
- Kept the designed cyan/white and purple rim highlights that belong to the 3D surface.
- Checked the transparent master against white and charcoal backgrounds and inspected enlarged left/right contour crops.

## Consistency
All symbol sizes are resized from `logo/master/plinth-symbol-master-transparent.png`. All lockups and icons use that same master; no independent re-generation of the P shape is used.

## Format caveat
The 3D P is a raster master. SVG deliverables are self-contained wrappers with embedded PNG artwork for visual fidelity. `symbol-vector-*.png` is retained as a backwards-compatible legacy filename, but those files are PNG exports, not vector path data. A true editable Bézier/3D vector reconstruction is not included in this batch.
